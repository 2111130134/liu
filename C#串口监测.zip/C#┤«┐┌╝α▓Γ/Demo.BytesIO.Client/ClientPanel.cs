﻿using STTech.BytesIO.Core;
using STTech.BytesIO.Serial;
using STTech.BytesIO.Tcp;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Demo.BytesIO.Client
{
    public partial class ClientPanel : UserControl
    {
        private BytesClient client;

        private ClientPanel()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
        }

        // 构造函数，接收一个 BytesClient 对象作为参数
        public ClientPanel(BytesClient client) : this()
        {
            this.client = client;
            propertyGrid.SelectedObject = client;

            // 为事件绑定相应的处理方法
            client.OnDataReceived += Client_OnDataReceived;
            client.OnConnectedSuccessfully += Client_OnConnectedSuccessfully;
            client.OnDisconnected += Client_OnDisconnected;
            client.OnDataSent += Client_OnDataSent;
        }

        // 处理数据发送完成事件
        private void Client_OnDataSent(object sender, STTech.BytesIO.Core.Entity.DataSentEventArgs e)
        {
            Print($"发送数据：{e.Data.EncodeToString("GBK")}");
        }

        // 处理断开连接事件
        private void Client_OnDisconnected(object sender, STTech.BytesIO.Core.Entity.DisconnectedEventArgs e)
        {
            Print($"已断开({e.ReasonCode})");
        }

        // 处理连接成功事件
        private void Client_OnConnectedSuccessfully(object sender, STTech.BytesIO.Core.Entity.ConnectedSuccessfullyEventArgs e)
        {
            Print("连接成功");
        }

        // 处理收到数据事件
        private void Client_OnDataReceived(object sender, STTech.BytesIO.Core.Entity.DataReceivedEventArgs e)
        {
            Print($"收到数据：{e.Data.EncodeToString("GBK")}");
        }

        // 处理连接按钮点击事件
        private void btnConnect_Click(object sender, EventArgs e)
        {
            client.Connect();
        }

        // 处理断开连接按钮点击事件
        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            client.Disconnect();
        }

        // 处理发送按钮点击事件
        private void btnSend_Click(object sender, EventArgs e)
        {
            client.Send(tbSend.Text.GetBytes("GBK"));
        }

        // 在文本框中打印消息
        private void Print(string msg)
        {
            tbRecv.AppendText($"[{DateTime.Now}] {msg}\r\n");
        }

        private void propertyGrid_Click(object sender, EventArgs e)
        {

        }
    }
}